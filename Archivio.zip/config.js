var prop = {
    state: {
        timeLeft: 180,
        elixir: {
            quantity: 0
        }
    },
    conf : {
        carte: {
            formica: {
                name: "la formica",
                elixir: 2
            },
            calabrone: {
                name: "il calabrone",
                elixir: 3
            },
        }
    }
}
